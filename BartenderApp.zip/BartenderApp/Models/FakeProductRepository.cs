﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BartenderApp.Models
{
    public class FakeProductRepository /*: IProductRepository*/
    {
        public IEnumerable<Product> Products => new List<Product> {
 new Product { Name = "Tequila Sunrise", Price = 8 },
 new Product { Name = "Screwdriver", Price = 12 },
 new Product { Name = "Martini", Price = 10 }
 };
    }
}
