﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace BartenderApp.Models
{
    public class Order
    {
        [BindNever]
 public int OrderID { get; set; }
        [BindNever]
        public ICollection<CartLine> Lines { get; set; }
        [BindNever]
        public bool Selected { get; set; }

        [Required(ErrorMessage = "Please enter table number")]
        [Range(0, 100, ErrorMessage = "Please enter a valid table number 1-100")]
        public int Table { get; set; }
       
    }
}
